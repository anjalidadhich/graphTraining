const sum = (n1, n2) => n1 + n2;

const getFirstName = (fullName) => fullName.split(" ")[0];

module.exports = { sum, getFirstName };
