function HomePage() {
  return (
    <>
      <h1>Home Page Loaded</h1>
    </>
  );
}

export default HomePage;
