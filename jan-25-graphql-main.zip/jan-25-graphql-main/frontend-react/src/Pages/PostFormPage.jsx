import PostForm from "../Components/PostForm";

function PostFormPage() {
  return (
    <>
      <PostForm />
    </>
  );
}

export default PostFormPage;
